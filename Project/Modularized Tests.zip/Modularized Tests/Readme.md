- *Modularized Test Scenarios*

- Base URL is stored in cypress.json file, making it easier for changing the url or port number
- Admin's email address and password are stored in variables as well. Just in case they are changed.
- Other changes vary in different test cases
- General modularization in all cases:
	- Components
	- Messages received
	- IDs
	- Text typed